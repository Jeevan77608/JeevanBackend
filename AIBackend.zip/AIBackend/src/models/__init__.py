"""Pydantic models and schemas."""

